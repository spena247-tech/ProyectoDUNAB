package Main;

import Model.RegistroUsuarios;
import javax.swing.*;
import java.awt.*;

/** Pantalla de acceso y registro para las cuentas del prototipo. */
public final class AccesoDunab extends JFrame {
    private static final Color NAVY=new Color(24,55,76),TEAL=new Color(40,160,190),BG=new Color(245,247,249),INK=new Color(38,53,65);
    private final CardLayout cards=new CardLayout(); private final JPanel forms=new JPanel(cards); private String cuenta;
    private AccesoDunab(){
        setTitle("DUNAB | Acceso");setDefaultCloseOperation(EXIT_ON_CLOSE);setSize(1217,527);setMinimumSize(new Dimension(960,500));setLocationRelativeTo(null);
        JPanel shell=new JPanel(new GridBagLayout());shell.setBackground(Color.WHITE);GridBagConstraints c=new GridBagConstraints();c.gridy=0;c.fill=GridBagConstraints.BOTH;c.weighty=1;c.gridx=0;c.weightx=.42;shell.add(heroPanel(),c);c.gridx=1;c.weightx=.58;forms.setBackground(Color.WHITE);forms.add(loginForm(),"login");forms.add(registerForm(),"register");shell.add(forms,c);setContentPane(shell);
    }
    private JPanel heroPanel(){
        JPanel hero=new JPanel(new BorderLayout());hero.setBackground(NAVY);hero.setBorder(BorderFactory.createEmptyBorder(18,20,18,20));
        JLabel logo=new JLabel("◇  DUNAB");logo.setForeground(Color.WHITE);logo.setFont(new Font("SansSerif",Font.BOLD,29));hero.add(logo,BorderLayout.NORTH);
        JPanel story=new JPanel();story.setOpaque(false);story.setLayout(new BoxLayout(story,BoxLayout.Y_AXIS));story.setBorder(BorderFactory.createEmptyBorder(62,0,0,0));
        JLabel intro=heroText("Tu camino a los",24,Color.WHITE,false);JLabel target=heroText("10.000 DUNAB",43,new Color(84,205,220),true);story.add(intro);story.add(Box.createVerticalStrut(7));story.add(target);story.add(Box.createVerticalStrut(63));
        JLabel desc=heroText("<html>Consulta tus movimientos,<br>encuentra actividades y sigue<br>tu progreso durante tu vida universitaria.</html>",16,new Color(217,230,237),false);story.add(desc);hero.add(story,BorderLayout.CENTER);
        JPanel benefits=new JPanel();benefits.setOpaque(false);benefits.setLayout(new BoxLayout(benefits,BoxLayout.Y_AXIS));benefits.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));benefits.add(benefit("◎","Organiza tus DUNAB"));benefits.add(Box.createVerticalStrut(5));benefits.add(benefit("▦","Explora encuentros"));benefits.add(Box.createVerticalStrut(5));benefits.add(benefit("◎","Alcanza tus metas"));hero.add(benefits,BorderLayout.SOUTH);return hero;
    }
    private JLabel heroText(String text,int size,Color color,boolean bold){JLabel l=new JLabel(text);l.setForeground(color);l.setFont(new Font("SansSerif",bold?Font.BOLD:Font.PLAIN,size));l.setAlignmentX(Component.LEFT_ALIGNMENT);return l;}
    private JLabel benefit(String icon,String text){JLabel l=new JLabel(icon+"   "+text);l.setForeground(new Color(87,205,220));l.setFont(new Font("SansSerif",Font.PLAIN,19));l.setAlignmentX(Component.LEFT_ALIGNMENT);return l;}
    private JPanel formPanel(int top){JPanel p=new JPanel();p.setBackground(Color.WHITE);p.setBorder(BorderFactory.createEmptyBorder(top,46,22,46));p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));return p;}
    private JLabel title(String t){JLabel l=new JLabel(t);l.setFont(new Font("SansSerif",Font.BOLD,30));l.setForeground(INK);l.setAlignmentX(Component.LEFT_ALIGNMENT);return l;}
    private JLabel caption(String t){JLabel l=new JLabel(t);l.setFont(new Font("SansSerif",Font.PLAIN,13));l.setForeground(new Color(112,128,139));l.setAlignmentX(Component.LEFT_ALIGNMENT);return l;}
    private JLabel fieldLabel(String t){JLabel l=caption(t);l.setForeground(new Color(50,72,88));return l;}
    private JTextField input(String hint){PromptField f=new PromptField(hint);styleField(f);return f;}
    private JPasswordField password(String hint){PromptPasswordField f=new PromptPasswordField(hint);styleField(f);return f;}
    private void styleField(JTextField f){f.setBackground(new Color(247,249,250));f.setForeground(INK);f.setCaretColor(INK);f.setFont(new Font("SansSerif",Font.PLAIN,14));f.setBorder(BorderFactory.createEmptyBorder(10,11,10,11));f.setPreferredSize(new Dimension(100,53));f.setMinimumSize(new Dimension(100,53));f.setMaximumSize(new Dimension(Integer.MAX_VALUE,53));f.setAlignmentX(Component.LEFT_ALIGNMENT);}
    private JButton action(String text){JButton b=new JButton(text);b.setBackground(TEAL);b.setForeground(Color.WHITE);b.setFont(new Font("SansSerif",Font.BOLD,15));b.setFocusPainted(false);b.setBorderPainted(false);b.setAlignmentX(Component.LEFT_ALIGNMENT);b.setPreferredSize(new Dimension(100,61));b.setMinimumSize(new Dimension(100,61));b.setMaximumSize(new Dimension(Integer.MAX_VALUE,61));return b;}
    private JButton link(String text){JButton b=new JButton(text);b.setBorderPainted(false);b.setContentAreaFilled(false);b.setFocusPainted(false);b.setForeground(TEAL);b.setFont(new Font("SansSerif",Font.BOLD,13));b.setAlignmentX(Component.CENTER_ALIGNMENT);b.setMaximumSize(new Dimension(Integer.MAX_VALUE,28));return b;}
    private JPanel loginForm(){
        JPanel p=formPanel(47);p.add(title("Bienvenido"));p.add(Box.createVerticalStrut(3));p.add(caption("Inicia sesión para continuar a tu cuenta."));p.add(Box.createVerticalStrut(58));
        JTextField email=input("Escribe tu correo institucional");JPasswordField pass=password("Ingresa tu contraseña");p.add(fieldLabel("Correo electrónico"));p.add(Box.createVerticalStrut(8));p.add(email);p.add(Box.createVerticalStrut(10));p.add(fieldLabel("Contraseña"));p.add(Box.createVerticalStrut(8));p.add(pass);p.add(Box.createVerticalStrut(0));
        JButton go=action("Iniciar sesión");go.addActionListener(e->{char[] pw=pass.getPassword();try{if(RegistroUsuarios.autenticar(email.getText(),pw)){cuenta=email.getText().trim().toLowerCase();dispose();new MenuPrincipal(Model.DatosDunab.cargar(cuenta)).setVisible(true);}else JOptionPane.showMessageDialog(this,"Correo o contraseña incorrectos.","Acceso",JOptionPane.WARNING_MESSAGE);}finally{java.util.Arrays.fill(pw,'\0');}});p.add(go);p.add(Box.createVerticalStrut(8));JButton reg=link("¿No tienes cuenta? Crear cuenta");reg.addActionListener(e->cards.show(forms,"register"));p.add(reg);p.add(Box.createVerticalGlue());JLabel footer=caption("Universidad Autónoma de Bucaramanga");footer.setFont(new Font("SansSerif",Font.PLAIN,11));footer.setAlignmentX(Component.CENTER_ALIGNMENT);p.add(footer);return p;
    }
    private Component registerForm(){
        JPanel p=formPanel(27);p.add(title("Crear cuenta"));p.add(Box.createVerticalStrut(3));p.add(caption("Regístrate para guardar tu progreso."));p.add(Box.createVerticalStrut(15));
        JTextField name=input("Escribe tu nombre completo"),uid=input("Escribe tu código estudiantil"),email=input("Escribe tu correo institucional");JPasswordField pass=password("Mínimo 8 caracteres"),confirm=password("Confirma tu contraseña");
        addField(p,"Nombre completo *",name);addField(p,"UID / código estudiantil *",uid);addField(p,"Correo institucional *",email);addField(p,"Contraseña (mínimo 8 caracteres) *",pass);addField(p,"Confirmar contraseña *",confirm);
        JButton create=action("Crear cuenta");create.addActionListener(e->{char[] pw=pass.getPassword(),again=confirm.getPassword();try{if(uid.getText().trim().isBlank())throw new IllegalArgumentException("Ingresa tu UID o código estudiantil.");if(!java.util.Arrays.equals(pw,again))throw new IllegalArgumentException("Las contraseñas no coinciden.");cuenta=RegistroUsuarios.registrar(name.getText(),email.getText(),pw);Model.DatosDunab datos=Model.DatosDunab.cargar(cuenta);datos.perfil.codigoEstudiante=uid.getText().trim();datos.guardar();dispose();new MenuPrincipal(datos).setVisible(true);}catch(IllegalArgumentException ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Registro",JOptionPane.WARNING_MESSAGE);}catch(IllegalStateException ex){JOptionPane.showMessageDialog(this,"No se pudieron guardar los datos del perfil: "+ex.getMessage(),"Registro",JOptionPane.WARNING_MESSAGE);}finally{java.util.Arrays.fill(pw,'\0');java.util.Arrays.fill(again,'\0');}});p.add(Box.createVerticalStrut(5));p.add(create);p.add(Box.createVerticalStrut(5));JButton back=link("← Volver al inicio de sesión");back.addActionListener(e->cards.show(forms,"login"));p.add(back);
        JScrollPane scroll=new JScrollPane(p);scroll.setBorder(null);scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);scroll.getVerticalScrollBar().setUnitIncrement(18);scroll.getViewport().setBackground(Color.WHITE);return scroll;
    }
    private void addField(JPanel panel,String label,JTextField field){panel.add(fieldLabel(label));panel.add(Box.createVerticalStrut(4));panel.add(field);panel.add(Box.createVerticalStrut(7));}
    private static final class PromptField extends JTextField{private final String prompt;PromptField(String prompt){this.prompt=prompt;}@Override protected void paintComponent(java.awt.Graphics g){super.paintComponent(g);if(getText().isEmpty()&&!hasFocus()){g.setColor(new Color(145,160,170));g.setFont(getFont());g.drawString(prompt,11,getHeight()/2+5);}}}
    private static final class PromptPasswordField extends JPasswordField{private final String prompt;PromptPasswordField(String prompt){this.prompt=prompt;}@Override protected void paintComponent(java.awt.Graphics g){super.paintComponent(g);if(getPassword().length==0&&!hasFocus()){g.setColor(new Color(145,160,170));g.setFont(getFont());g.drawString(prompt,11,getHeight()/2+5);}}}    public static void abrir(){new AccesoDunab().setVisible(true);}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    //GEN-BEGIN:initComponents
    private void initComponents() {
        jLabel1 = new javax.swing.JLabel();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jLabel1.setText("Vista DUNAB");
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel1));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel1));
        pack();
    }
    //GEN-END:initComponents
    // </editor-fold>
    //GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    //GEN-END:variables
}



