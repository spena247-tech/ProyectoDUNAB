package Main;
public class MainMenu {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(AccesoDunab::abrir);
    }
}
