package Model;
import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.util.*;

/** Datos de una cuenta, persistidos en un archivo local independiente. */
public class DatosDunab implements Serializable {
    private static final long serialVersionUID=1L;
    public Perfil perfil=new Perfil();
    public ArrayList<Movimiento> movimientos=new ArrayList<>();
    public ArrayList<Meta> metas=new ArrayList<>();
    public ArrayList<String> encuentros=new ArrayList<>();
    public String tema="Claro";
    public boolean notificaciones=true,recordatorios=true,actualizaciones=true,resumenSemanal=true;
    public Boolean vistaCompacta=false;
    public Boolean mostrarProgresoMenu=true;
    public String cuenta="";
    private static Path dir(){return Paths.get(System.getProperty("user.home"),".dunab");}
    private static Path archivo(String correo){try{byte[] h=MessageDigest.getInstance("SHA-256").digest(correo.trim().toLowerCase(Locale.ROOT).getBytes(java.nio.charset.StandardCharsets.UTF_8));return dir().resolve("datos-"+Base64.getUrlEncoder().withoutPadding().encodeToString(h)+".ser");}catch(Exception e){throw new IllegalStateException(e);}}
    /** Compatibilidad con la versión anterior. */
    public static DatosDunab cargar(){try(ObjectInputStream in=new ObjectInputStream(Files.newInputStream(dir().resolve("datos.ser")))){return (DatosDunab)in.readObject();}catch(Exception e){return new DatosDunab();}}
    public static DatosDunab cargar(String correo){Path path=archivo(correo);try(ObjectInputStream in=new ObjectInputStream(Files.newInputStream(path))){DatosDunab d=(DatosDunab)in.readObject();d.cuenta=correo;return d;}catch(Exception ignored){}
        DatosDunab d=new DatosDunab();d.cuenta=correo;
        // Migra los datos previos solo cuando su perfil corresponde a la cuenta que inició sesión.
        DatosDunab old=cargar();boolean legacySinCuenta=old.perfil.correo==null||old.perfil.correo.isBlank();if(legacySinCuenta||old.perfil.correo.equalsIgnoreCase(correo)){d=old;d.cuenta=correo;if(d.perfil.nombre==null||d.perfil.nombre.equals("Estudiante DUNAB"))d.perfil.nombre=RegistroUsuarios.nombre(correo);d.perfil.correo=correo;d.guardar();if(legacySinCuenta)try{Files.move(dir().resolve("datos.ser"),dir().resolve("datos-migrado.ser"),StandardCopyOption.REPLACE_EXISTING);}catch(IOException ignored){}}
        else {d.perfil.nombre=RegistroUsuarios.nombre(correo);d.perfil.correo=correo;d.guardar();}return d;
    }
    public void guardar(){Path target=cuenta==null||cuenta.isBlank()?dir().resolve("datos.ser"):archivo(cuenta);try{Files.createDirectories(target.getParent());Path temp=target.resolveSibling(target.getFileName()+".tmp");try(ObjectOutputStream out=new ObjectOutputStream(Files.newOutputStream(temp))){out.writeObject(this);}try{Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING);}}catch(IOException e){throw new IllegalStateException("No se pudieron guardar los datos localmente: "+e.getMessage(),e);}}
    public int saldo(){return movimientos.stream().mapToInt(Movimiento::impacto).sum();}
}


