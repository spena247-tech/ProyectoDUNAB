package Model;
import java.io.Serializable;
import java.time.LocalDate;

public class Meta implements Serializable {
    private static final long serialVersionUID = 1L;
    public final String nombre;
    public final int objetivo;
    public int avance;
    public final LocalDate fechaLimite;
    public Meta(String nombre, int objetivo, LocalDate fechaLimite) { this.nombre=nombre; this.objetivo=objetivo; this.fechaLimite=fechaLimite; }
    public int porcentaje() { return objetivo <= 0 ? 0 : Math.min(100, avance*100/objetivo); }
}
