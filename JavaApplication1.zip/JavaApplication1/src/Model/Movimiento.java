package Model;
import java.io.Serializable;
import java.time.LocalDate;

public class Movimiento implements Serializable {
    private static final long serialVersionUID = 1L;
    public final LocalDate fecha;
    public final String tipo, descripcion;
    public final int cantidad;
    public Movimiento(LocalDate fecha, String tipo, String descripcion, int cantidad) {
        this.fecha=fecha; this.tipo=tipo; this.descripcion=descripcion; this.cantidad=cantidad;
    }
    public int impacto() { return tipo.equals("Ingreso") ? cantidad : -cantidad; }
}
