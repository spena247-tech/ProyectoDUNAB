package Model;
import java.io.Serializable;
import java.time.LocalDate;

public class Perfil implements Serializable {
    private static final long serialVersionUID = 1L;
    public String nombre = "Estudiante DUNAB";
    public String correo = "";
    public String programa = "";
    public String semestre = "";
    public String telefono = "";
    public String codigoEstudiante = "";
    public String sede = "";
}
