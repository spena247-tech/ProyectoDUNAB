package Model;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Registro local de cuentas para el prototipo académico. */
public final class RegistroUsuarios {
    private static final Path DIR=Paths.get(System.getProperty("user.home"),".dunab");
    private static final Path ARCHIVO=DIR.resolve("usuarios.ser");
    private static final int ITERACIONES=150_000;
    private RegistroUsuarios(){}
    private static class Cuenta implements Serializable {
        private static final long serialVersionUID=1L;
        String nombre,correo,salt,hash;
        Cuenta(String n,String c,String s,String h){nombre=n;correo=c;salt=s;hash=h;}
    }
    @SuppressWarnings("unchecked") private static Map<String,Cuenta> leer(){try(ObjectInputStream in=new ObjectInputStream(Files.newInputStream(ARCHIVO))){return (Map<String,Cuenta>)in.readObject();}catch(Exception e){return new HashMap<>();}}
    private static void guardar(Map<String,Cuenta> cuentas){try{Files.createDirectories(DIR);Path temp=DIR.resolve("usuarios.tmp");try(ObjectOutputStream out=new ObjectOutputStream(Files.newOutputStream(temp))){out.writeObject(cuentas);}try{Files.move(temp,ARCHIVO,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,ARCHIVO,StandardCopyOption.REPLACE_EXISTING);}}catch(IOException e){throw new IllegalStateException("No se pudo guardar el registro local: "+e.getMessage(),e);}}
    private static String clave(char[] password,byte[] salt){try{PBEKeySpec spec=new PBEKeySpec(password,salt,ITERACIONES,256);byte[] b=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();return Base64.getEncoder().encodeToString(b);}catch(Exception e){throw new IllegalStateException("No se pudo proteger la contraseña.",e);}}
    public static synchronized String registrar(String nombre,String correo,char[] password){String c=correo.trim().toLowerCase(Locale.ROOT);if(nombre.isBlank()||!c.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")||password.length<8)throw new IllegalArgumentException("Ingresa nombre, correo válido y una contraseña de al menos 8 caracteres.");Map<String,Cuenta> m=leer();if(m.containsKey(c))throw new IllegalArgumentException("Ya existe una cuenta con ese correo.");byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);m.put(c,new Cuenta(nombre.trim(),c,Base64.getEncoder().encodeToString(salt),clave(password,salt)));guardar(m);return c;}
    public static synchronized boolean autenticar(String correo,char[] password){String c=correo.trim().toLowerCase(Locale.ROOT);Cuenta u=leer().get(c);if(u==null)return false;byte[] salt=Base64.getDecoder().decode(u.salt);return MessageDigest.isEqual(Base64.getDecoder().decode(u.hash),Base64.getDecoder().decode(clave(password,salt)));}
    public static synchronized String nombre(String correo){Cuenta u=leer().get(correo.trim().toLowerCase(Locale.ROOT));return u==null?"Estudiante":u.nombre;}
}
